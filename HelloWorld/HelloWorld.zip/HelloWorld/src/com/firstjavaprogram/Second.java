package com.firstjavaprogram;

public class Second {


    public static void main(String[] args){
        int x = 5;
        System.out.println(x+5);
    }



}
